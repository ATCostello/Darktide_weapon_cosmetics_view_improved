local mod = get_mod("weapon_cosmetics_view_improved")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,

	options = {
		widgets = {
			{
				setting_id = "general_settings",
				type = "group",

				sub_widgets = {
					{
						setting_id = "mod_name_pizazz_toggle",
						type = "checkbox",
						default_value = true,
						tooltip = "mod_name_pizazz_tooltip",
					},
					{
						setting_id = "show_unobtainable",
						type = "checkbox",
						default_value = false,
						tooltip = "show_unobtainable_tooltip",
					},
				},
			},
		},
	},
}

local mod = get_mod("weapon_cosmetics_view_improved")

return settings("weapon_cosmetics_view_improved_settings")
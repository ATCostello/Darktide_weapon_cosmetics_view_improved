local mod = get_mod("weapon_cosmetics_view_improved")

local definitions = {

}

return definitions